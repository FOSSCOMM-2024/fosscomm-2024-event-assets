The assets folder contains the logos of osuom and aws/pdg along with specific svgs with the design of each side. These assets are provided in case they are needed.

The fosscomm_2024_lanyard_gradient.svg file includes all these assets along with a design of how the final lanyard should look like.


Made by OpenSource UoM.